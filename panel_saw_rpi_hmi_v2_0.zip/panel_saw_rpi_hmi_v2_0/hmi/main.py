
import argparse
import sys
from pathlib import Path
from datetime import datetime
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
from PySide6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QStackedWidget, QGridLayout, QLineEdit, QMessageBox, QFrame

sys.path.append(str(Path(__file__).resolve().parents[1]))
from protocol.panel_saw_protocol import Simulator, pkt_jog, pkt_move_abs, pkt_stop, pkt_home, pkt_reset_alarm, AXIS_FENCE, AXIS_HEIGHT, AXIS_TILT

class Comm:
    def __init__(self):
        self.sim = Simulator()
    def send(self, p):
        self.sim.handle_packet(p)
    def status(self):
        return self.sim.update()

class Card(QFrame):
    def __init__(self):
        super().__init__()
        self.setObjectName("Card")

class HMI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.comm = Comm()
        self.setWindowTitle("Panel Saw Controller v2.0")
        self.setMinimumSize(1024, 600)

        outer = QWidget()
        self.setCentralWidget(outer)
        main = QHBoxLayout(outer)
        main.setContentsMargins(0,0,0,0)

        nav_frame = QFrame()
        nav_frame.setObjectName("Nav")
        nav_frame.setFixedWidth(170)
        nav = QVBoxLayout(nav_frame)
        main.addWidget(nav_frame)

        title = QLabel("PANEL\nSAW")
        title.setAlignment(Qt.AlignCenter)
        title.setFont(QFont("Arial", 21, QFont.Bold))
        nav.addWidget(title)

        self.stack = QStackedWidget()
        main.addWidget(self.stack)
        self.nav_buttons = []
        for label, idx in [("HOME",0),("MANUAL",1),("AUTO",2),("DIAG",3),("ALARMS",4),("SETTINGS",5)]:
            b = QPushButton(label)
            b.setMinimumHeight(66)
            b.setFont(QFont("Arial", 14, QFont.Bold))
            b.clicked.connect(lambda _, i=idx: self.show_page(i))
            nav.addWidget(b)
            self.nav_buttons.append(b)
        nav.addStretch()
        brand = QLabel("GreenBoard\nElectronics")
        brand.setAlignment(Qt.AlignCenter)
        nav.addWidget(brand)

        self.stack.addWidget(self.home_page())
        self.stack.addWidget(self.manual_page())
        self.stack.addWidget(self.auto_page())
        self.stack.addWidget(self.diag_page())
        self.stack.addWidget(self.alarm_page())
        self.stack.addWidget(self.settings_page())

        self.show_page(0)
        self.timer = QTimer()
        self.timer.timeout.connect(self.refresh)
        self.timer.start(250)
        self.refresh()

    def show_page(self, idx):
        self.stack.setCurrentIndex(idx)
        for i, b in enumerate(self.nav_buttons):
            b.setProperty("active", i == idx)
            b.style().unpolish(b); b.style().polish(b)

    def page(self, title):
        w = QWidget()
        l = QVBoxLayout(w)
        l.setContentsMargins(18, 14, 18, 14)
        h = QHBoxLayout()
        t = QLabel(title)
        t.setFont(QFont("Arial", 23, QFont.Bold))
        h.addWidget(t)
        h.addStretch()
        self.clock = QLabel("")
        self.clock.setFont(QFont("Arial", 12, QFont.Bold))
        h.addWidget(self.clock)
        l.addLayout(h)
        return w, l

    def metric(self, title, value):
        c = Card()
        l = QVBoxLayout(c)
        a = QLabel(title)
        a.setFont(QFont("Arial", 12, QFont.Bold))
        b = QLabel(value)
        b.setObjectName("Metric")
        b.setFont(QFont("Arial", 22, QFont.Bold))
        b.setAlignment(Qt.AlignCenter)
        l.addWidget(a); l.addWidget(b)
        return c, b

    def home_page(self):
        w,l = self.page("PANEL SAW CONTROLLER v2.0")
        grid = QGridLayout()
        self.m_state, self.v_state = self.metric("STATUS", "READY")
        self.m_fence, self.v_fence = self.metric("FENCE POSITION", "0.00 mm")
        self.m_height, self.v_height = self.metric("BLADE HEIGHT", "0.0 mm")
        self.m_tilt, self.v_tilt = self.metric("BLADE TILT", "90.0°")
        self.m_safety, self.v_safety = self.metric("SAFETY", "OK")
        self.m_alarm, self.v_alarm = self.metric("ALARM", "None")
        for i, c in enumerate([self.m_state,self.m_fence,self.m_height,self.m_tilt,self.m_safety,self.m_alarm]):
            grid.addWidget(c, i//2, i%2)
        l.addLayout(grid)
        row = QHBoxLayout()
        for txt in ["START CYCLE", "MACHINE STOP", "RESET"]:
            b = QPushButton(txt)
            b.setMinimumHeight(65)
            b.setFont(QFont("Arial", 16, QFont.Bold))
            row.addWidget(b)
            if txt == "MACHINE STOP":
                b.setObjectName("StopButton")
                b.clicked.connect(lambda: self.comm.send(pkt_stop()))
            if txt == "RESET":
                b.clicked.connect(lambda: self.comm.send(pkt_reset_alarm()))
        l.addLayout(row)
        return w

    def manual_page(self):
        w,l = self.page("MANUAL OPERATION")
        grid = QGridLayout()
        axes = [("FENCE X", AXIS_FENCE, "JOG -", "JOG +", 50), ("BLADE HEIGHT", AXIS_HEIGHT, "DOWN", "UP", 10), ("BLADE TILT", AXIS_TILT, "TILT -", "TILT +", 5)]
        for col,(name,axis,neg,pos,speed) in enumerate(axes):
            c = Card(); cl = QVBoxLayout(c)
            lab = QLabel(name); lab.setAlignment(Qt.AlignCenter); lab.setFont(QFont("Arial", 16, QFont.Bold)); cl.addWidget(lab)
            r = QHBoxLayout()
            for txt, direction in [(neg,-1),(pos,1)]:
                b = QPushButton(txt); b.setMinimumHeight(82); b.setFont(QFont("Arial", 15, QFont.Bold))
                b.pressed.connect(lambda a=axis,d=direction,sp=speed: self.comm.send(pkt_jog(a,d,sp)))
                b.released.connect(lambda a=axis: self.comm.send(pkt_stop(a)))
                r.addWidget(b)
            cl.addLayout(r)
            grid.addWidget(c,0,col)
        l.addLayout(grid)
        home = QPushButton("HOME ALL AXES")
        home.setMinimumHeight(75); home.setFont(QFont("Arial", 18, QFont.Bold))
        home.clicked.connect(lambda: self.comm.send(pkt_home()))
        l.addWidget(home)
        return w

    def auto_page(self):
        w,l = self.page("AUTO POSITIONING")
        self.in_fence = QLineEdit("1200.00"); self.in_height = QLineEdit("75.0"); self.in_tilt = QLineEdit("90.0")
        grid = QGridLayout()
        for i,(name,edit) in enumerate([("Fence target mm",self.in_fence),("Blade height mm",self.in_height),("Blade tilt deg",self.in_tilt)]):
            c=Card(); cl=QVBoxLayout(c)
            lab=QLabel(name); lab.setFont(QFont("Arial",16,QFont.Bold))
            edit.setMinimumHeight(70); edit.setFont(QFont("Arial",24,QFont.Bold))
            cl.addWidget(lab); cl.addWidget(edit)
            grid.addWidget(c,0,i)
        l.addLayout(grid)
        move=QPushButton("MOVE TO POSITION")
        move.setMinimumHeight(90); move.setFont(QFont("Arial",20,QFont.Bold))
        move.clicked.connect(self.move_auto)
        l.addWidget(move)
        return w

    def diag_page(self):
        w,l = self.page("DIAGNOSTICS")
        self.diag=QLabel(""); self.diag.setObjectName("DiagText"); self.diag.setAlignment(Qt.AlignTop); self.diag.setFont(QFont("Courier New",16))
        l.addWidget(self.diag)
        return w

    def alarm_page(self):
        w,l = self.page("ALARMS")
        self.alarm=QLabel("No active alarms"); self.alarm.setAlignment(Qt.AlignCenter); self.alarm.setFont(QFont("Arial",28,QFont.Bold))
        l.addWidget(self.alarm)
        reset=QPushButton("RESET ALARM"); reset.setMinimumHeight(85); reset.clicked.connect(lambda: self.comm.send(pkt_reset_alarm()))
        l.addWidget(reset)
        return w

    def settings_page(self):
        w,l = self.page("SETTINGS")
        txt=QLabel("Version 2.0 Settings\n\nNext: calibration, limits, passwords, branding, RS-485 port.")
        txt.setAlignment(Qt.AlignCenter); txt.setFont(QFont("Arial",22,QFont.Bold))
        l.addWidget(txt)
        return w

    def move_auto(self):
        try:
            self.comm.send(pkt_move_abs(AXIS_FENCE, float(self.in_fence.text()), 80))
            self.comm.send(pkt_move_abs(AXIS_HEIGHT, float(self.in_height.text()), 15))
            self.comm.send(pkt_move_abs(AXIS_TILT, float(self.in_tilt.text()), 8))
        except ValueError:
            QMessageBox.warning(self, "Input error", "Enter valid numbers.")

    def refresh(self):
        s=self.comm.status()
        self.clock.setText(datetime.now().strftime("%d/%m/%Y  %H:%M:%S"))
        self.v_state.setText(s.state); self.v_fence.setText(f"{s.fence_mm:.2f} mm")
        self.v_height.setText(f"{s.height_mm:.1f} mm"); self.v_tilt.setText(f"{s.tilt_deg:.1f}°")
        self.v_safety.setText("OK" if s.estop_ok and s.guard_closed and s.servo_power else "NOT SAFE")
        self.v_alarm.setText(s.alarm if s.alarm else "None")
        self.alarm.setText(s.alarm if s.alarm else "No active alarms")
        self.diag.setText(f"Machine state      : {s.state}\nMode               : {s.mode}\nRS-485 Link         : {'OK' if s.rs485_ok else 'FAULT'}\n\nFence position      : {s.fence_mm:8.2f} mm\nFence target        : {s.fence_target:8.2f} mm\nBlade height        : {s.height_mm:8.1f} mm\nBlade height target : {s.height_target:8.1f} mm\nBlade tilt          : {s.tilt_deg:8.1f} deg\nBlade tilt target   : {s.tilt_target:8.1f} deg\n\nE-stop OK           : {s.estop_ok}\nBlade guard closed  : {s.guard_closed}\nRear guard closed   : {s.rear_guard_closed}\nServo power OK      : {s.servo_power}\nVacuum OK           : {s.vacuum_ok}\nSaw running         : {s.saw_running}\n")

def main():
    parser=argparse.ArgumentParser(); parser.add_argument("--simulate", action="store_true"); parser.parse_args()
    app=QApplication(sys.argv)
    app.setStyleSheet("""
        QWidget { background: #151a20; color: #f2f5f7; }
        #Nav { background: #0d1117; border-right: 2px solid #303845; }
        QPushButton { background: #26384c; color: white; border: 1px solid #4e6682; border-radius: 8px; padding: 8px; }
        QPushButton[active="true"] { background: #1976d2; }
        QPushButton:pressed { background: #5d789a; }
        #StopButton { background: #b3261e; }
        #Card { background: #1d2630; border: 2px solid #3b4b5b; border-radius: 12px; padding: 8px; }
        #Metric { color: #7CFF7C; }
        QLineEdit { background: #090d12; color: #00ff99; border: 2px solid #61758d; border-radius: 8px; padding: 8px; }
        #DiagText { background: #0a0d10; border: 2px solid #3b4b5b; padding: 12px; }
    """)
    h=HMI(); h.showFullScreen(); sys.exit(app.exec())

if __name__ == "__main__":
    main()
