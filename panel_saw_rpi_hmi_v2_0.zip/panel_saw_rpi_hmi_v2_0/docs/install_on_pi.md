# Install on Raspberry Pi

Copy the ZIP to the Pi and extract it.

Run:
    cd ~/panelsawHMI/panel_saw_rpi_hmi_v2_0
    chmod +x run_hmi.sh
    ./run_hmi.sh
